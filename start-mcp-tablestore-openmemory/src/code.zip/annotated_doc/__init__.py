from .main import Doc as Doc

__version__ = "0.0.4"
